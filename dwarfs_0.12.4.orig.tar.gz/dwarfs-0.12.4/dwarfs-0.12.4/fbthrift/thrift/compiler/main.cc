/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * thrift - a lightweight cross-language rpc/serialization tool
 *
 * This file contains the main compiler engine for Thrift, which invokes the
 * scanner/parser to build the thrift object tree. The interface generation
 * code for each language lives in a file by the language name under the
 * generate/ folder, and all parse structures live in parse/
 *
 */

#include <thrift/compiler/compiler.h>

using namespace apache::thrift::compiler;

// Disable expensive malloc debugging features that cause up to 3x slowdown
// when compiling .thrift files.
const char* malloc_conf = "junk:false,debug_double_free_max_scan:0";

int main(int argc, char** argv) {
  source_manager sm;
  auto result = compile({argv, argv + argc}, sm);
  for (const auto& diag : result.detail.diagnostics()) {
    fmt::print(stderr, "{}\n", diag);
  }
  return static_cast<int>(result.retcode);
}
